let perguntas = [
  {
    pergunta: "Qual área sofre mais desmatamento?",
    opcoes: ["Campo", "Cidade"],
    resposta: "Campo"
  },
  {
    pergunta: "Qual área tem maior impacto na expansão urbana?",
    opcoes: ["Campo", "Cidade"],
    resposta: "Cidade"
  },
  {
    pergunta: "Qual área é mais afetada por desmatamento para agricultura?",
    opcoes: ["Campo", "Cidade"],
    resposta: "Campo"
  },
  {
    pergunta: "Qual área contribui mais para a perda de biodiversidade?",
    opcoes: ["Campo", "Cidade"],
    resposta: "Campo"
  }
];

let perguntaAtual;
let opcaoSelecionada = null;
let respostaCorreta = false;

function setup() {
  createCanvas(600, 400);
  gerarPergunta();
  textAlign(CENTER, CENTER);
  textSize(20);
}

function gerarPergunta() {
  perguntaAtual = random(perguntas);
  opcaoSelecionada = null;
  respostaCorreta = false;
}

function draw() {
  background(220);
  
  // Mostrar a pergunta
  fill(0);
  text(perguntaAtual.pergunta, width / 2, 50);
  
  // Mostrar opções
  for (let i = 0; i < perguntaAtual.opcoes.length; i++) {
    let x = width / 2;
    let y = 150 + i * 80;
    fill(255);
    stroke(0);
    rectMode(CENTER);
    rect(x, y, 200, 50);
    
    fill(0);
    noStroke();
    text(perguntaAtual.opcoes[i], x, y);
  }
  
  // Indicação da resposta
  if (respostaCorreta) {
    fill(0, 200, 0);
    textSize(24);
    text("Resposta correta!", width / 2, height - 50);
  } else if (opcaoSelecionada) {
    fill(200, 0, 0);
    textSize(24);
    text("Resposta incorreta!", width / 2, height - 50);
  }
}

function mousePressed() {
  // Verifica se alguma opção foi clicada
  for (let i = 0; i < perguntaAtual.opcoes.length; i++) {
    let x = width / 2;
    let y = 150 + i * 80;
    if (
      mouseX > x - 100 && mouseX < x + 100 &&
      mouseY > y - 25 && mouseY < y + 25
    ) {
      opcaoSelecionada = perguntaAtual.opcoes[i];
      if (opcaoSelecionada === perguntaAtual.resposta) {
        respostaCorreta = true;
      } else {
        respostaCorreta = false;
      }
      
      // Depois de uma resposta, gera uma nova pergunta após um tempo
      setTimeout(() => {
        gerarPergunta();
      }, 1500);
    }
  }
}